
import UIKit

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        
    }
    
    // MARK: - UI Methods
    
    func validatePhoneNo(strPhNo : String) -> Bool
    {
        let phoneRegx2 = "[0-9]{3}-[0-9]{3}-[0-9]{4}$"
        let predicate : NSPredicate = NSPredicate(format: "SELF MATCHES %@", phoneRegx2)
        
        let isValid = predicate.evaluate(with: strPhNo)
        
        return isValid
    }
    
    func validateMobilePhone(strPhNo : String) -> Bool
    {
        let comparePhNo = strPhNo.replacingOccurrences(of: "-", with: "")
        let mobileNoPattern = "[0-9]{10}";//@"[789][0-9]{9}"; //begins with 789
        let predicate : NSPredicate = NSPredicate(format: "SELF MATCHES %@", mobileNoPattern)
        
        let isValid = predicate.evaluate(with: comparePhNo)
        
        return isValid
    }

    
    func setPhoneInDashFormat(strPhNo : String) -> String
    {
        var strWithoutDash = strPhNo.replacingOccurrences(of: "-", with: "")
        strWithoutDash = strWithoutDash.replacingOccurrences(of: " ", with: "")
        
        if strWithoutDash.isEmpty == true
        {
            return ""
        }
        
        if strWithoutDash.count == 12 && strWithoutDash.contains("")
        {
            return strWithoutDash
        }
        else{
            strWithoutDash.insert("-", at: strWithoutDash.index(strWithoutDash.startIndex, offsetBy: 3))
            strWithoutDash.insert("-", at: strWithoutDash.index(strWithoutDash.startIndex, offsetBy: 7))
            
            return strWithoutDash
        }
    }
    
    
    func replaceDashFromPhone(strPhNo : String) -> String {
        let strWithoutDash = strPhNo.replacingOccurrences(of: "-", with: "")
        return strWithoutDash
    }
    
    func validateEmail(strEmail : String) -> Bool {
        
        let emailPattern = "[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}$";
        
        let regExPattern : NSRegularExpression = try! NSRegularExpression(pattern: emailPattern, options: .caseInsensitive)
        
        let regExMatches = regExPattern.numberOfMatches(in: strEmail, options: [], range: NSRange(location: 0, length: strEmail.count))
        
        return (regExMatches == 0) ? false : true
    }
    
    func showHudForLoading() {
       
    }
    
    func showHudForProgress(progress : Float) {
        
    }
    
    func dismissHud() {
        
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
