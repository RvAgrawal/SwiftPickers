
import UIKit

class ViewController: BaseViewController, UITextFieldDelegate, DatePickerDelegate,GenericPickerDelegate,AlertMessageDelegate,ActionSheetDelegate,RatingViewDelegate{

    @IBOutlet weak var txtDate : UITextField?
    var pickerController : DatePicker?
    
    var genericPicker : GenericPicker?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
                
        //DatePicker
        pickerController = DatePicker()
        pickerController?.datePickerDelegate = self
        
        //Generic Picker
        genericPicker = GenericPicker()
        genericPicker?.genericPickerDelegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnSelectDateAction(_ sender: UIButton) {
        
        //DatePicker Setup
//        pickerController?.setupDatePicker(obj: sender, viewController: self)
        
        //AlertMessage Setup
//        AlertMessage.showAlert(viewController: self, title: "Test Title", message: "Test Message", cancelTitle: "Cancel", otherTitles: "Ok")
//        AlertMessage.alertMessageDelegate = self

        //ActionSheet Setup
        let arrObj = NSMutableArray(objects: "Show","Hide","Delete","Add")
        ActionSheet.showActionSheet(viewController: self, title: "Action Sheet", message: "", cancelTitle: "Cancel", otherTitles: arrObj)
        ActionSheet.actionSheetDelegate = self
    }
    
    @IBAction func btnRatingAction(_ sender: UIButton) {
        
        var ratingView : RatingView!
        ratingView = Bundle.main.loadNibNamed("RatingView", owner: nil, options: nil)![0] as! RatingView
        
        ratingView.frame = self.view.frame
        ratingView.ratingViewDelegate = self
        
        ratingView.alpha = 0.0
        
        self.view.addSubview(ratingView)
        self.view.bringSubview(toFront: ratingView)
        
        UIView.animate(withDuration: 0.8) {
            ratingView.alpha = 1.0
        }
    }
    
    
    public func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        //Uncomment To see DatePicker without minimum maximum
//        pickerController?.setupDatePicker(textField: textField, minimumDate: nil , maximumDate: nil)
        pickerController?.setupDatePicker(textField: textField, minimumDate: NSDate(timeInterval: -500000, since: NSDate() as Date), maximumDate: NSDate(timeInterval: 500000, since: NSDate() as Date))
        
        //Uncomment To see generic Picker
//        let arrObj = NSMutableArray(objects: "1","2","3","4","5","6","7","8","9")
//        genericPicker?.setupDatePicker(textField: self.txtDate!, arrObj: arrObj, key: "", isDict: false)
        
        return true
    }
    
    // MARK: - Delegate methods for RatingView
    
    func submitRatingClick(StrRateValue: String, ratingView: RatingView) {
        print(StrRateValue)
        ratingView.removeFromSuperview()
    }
    
    // MARK: - Delegate methods for Alert Message & Action Sheet
    
    func cancelClick(alertController: UIAlertController, index: Int) {
        print("cancel click from VC---- index : \(index)")
    }
    
    func otherClick(alertController: UIAlertController, index: Int) {
        print("other click from VC---- index : \(index)")
    }
    
    
    // MARK: - Delegate methods for Generic Picker
    
    func doneClick(strData: String, textField: UITextField, index: Int) {
        textField.text = strData
        textField.resignFirstResponder()
    }
    
    // MARK: - Delegate methods for DatePicker
    
    func doneClick(strDate: String, textField: UITextField) {
        print("date selected:\(strDate)")
        textField.text = strDate
        textField.resignFirstResponder()
    }
    
    func cancelClick(textField: UITextField) {
        textField.resignFirstResponder()
    }

    
    func doneVCClick(strDate: String, obj: Any) {
        let btnDate = obj as! UIButton
        btnDate.setTitle(strDate, for: .normal)
    }
    
    func cancelVCClick(obj: Any) {
        let btnDate = obj as! UIButton
        btnDate.setTitle("Select Date", for: .normal)
    }
}

