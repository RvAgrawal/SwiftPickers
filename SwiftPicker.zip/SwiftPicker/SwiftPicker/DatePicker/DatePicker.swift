

import UIKit

protocol DatePickerDelegate {
    
    //implement this methods for Textfield
    func doneClick(strDate:String,textField:UITextField)
    func cancelClick(textField:UITextField)
    
    //implement this methods for button
    func doneVCClick(strDate:String,obj:Any)
    func cancelVCClick(obj:Any)
}

class DatePicker: NSObject {

    // MARK: - Delegate for DatePicker
    
    var datePickerDelegate : DatePickerDelegate?
    
    // MARK: - Properties For Picker
    var datePicker : UIDatePicker!
    var pickerToolbar : UIToolbar!
    
    var selectedTextField : UITextField!
    var objControl : Any!
    
    
    // MARK: - Setup DatePicker
    
    func setupDatePicker(textField:UITextField, minimumDate:NSDate?, maximumDate:NSDate?)
    {
        self.selectedTextField = textField
        
        self.datePicker = UIDatePicker()
        self.datePicker.datePickerMode = .date
        self.datePicker.backgroundColor = UIColor.white
    
        //Setting Minimum And Maximum Date if they are not nil
        
        if minimumDate != nil
        {
            self.datePicker.date = minimumDate! as Date
            
            if maximumDate != nil{
                
                let today = NSDate()
                
                if today.compare(maximumDate! as Date) == .orderedAscending
                {
                    self.datePicker.maximumDate = today as Date
                }
                else
                {
                    self.datePicker.maximumDate  = maximumDate as Date?
                }
            }
            
            self.datePicker.minimumDate = minimumDate! as Date
        }
        
        //Setting datepicker as input view
        textField.inputView = self.datePicker

        // setup toolbar
        self.setupToolbar(textField: textField)
    }
    
    
    func setupDatePicker(obj: Any,viewController: UIViewController) {
        
        self.objControl = obj
        
        self.datePicker = UIDatePicker(frame: CGRect(x: 0, y: (UIScreen.main.bounds.size.height) - 200, width: UIScreen.main.bounds.size.width, height: 200))
        self.datePicker.datePickerMode = .date
        self.datePicker.backgroundColor = UIColor.white
        
        self.pickerToolbar = UIToolbar(frame: CGRect(x: 0, y: (UIScreen.main.bounds.size.height) - 240, width: self.datePicker.frame.size.width, height: 40))
        //        self.pickerToolbar.barStyle = .default
        
        let btnDone = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.btnDoneClickForVC))
        let btnCancel = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.btnCancelClickForVC))
        
        let fixedSpace:UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        self.pickerToolbar.items = NSArray(objects: btnCancel,fixedSpace,btnDone) as? [UIBarButtonItem]
        
        self.pickerToolbar.sizeToFit()
        self.pickerToolbar.barTintColor = UIColor.darkGray
        self.pickerToolbar.tintColor = UIColor.green
        self.pickerToolbar.isTranslucent = false
        
        viewController.view.addSubview(self.pickerToolbar)
        viewController.view.addSubview(self.datePicker)
    }
    
    func setupToolbar(textField:UITextField) {
        
        self.pickerToolbar = UIToolbar(frame: CGRect(x: 0, y: 100, width: self.datePicker.frame.size.width, height: 50))
        //        self.pickerToolbar.barStyle = .default
        
        let btnDone = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.btnDoneClick))
        let btnCancel = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.btnCancelClick))
        
        let fixedSpace:UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        self.pickerToolbar.items = NSArray(objects: btnCancel,fixedSpace,btnDone) as? [UIBarButtonItem]
        
        self.pickerToolbar.sizeToFit()
        self.pickerToolbar.barTintColor = UIColor.darkGray
        self.pickerToolbar.tintColor = UIColor.green
        self.pickerToolbar.isTranslucent = false
        
        //Setting Toolbar as input Accessory View
        textField.inputAccessoryView = self.pickerToolbar
        
    }


    // MARK: - Toolbar button Click
    
    @objc func btnDoneClickForVC()
    {
        self.datePicker.removeFromSuperview()
        self.pickerToolbar.removeFromSuperview()
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy"
        
        self.datePickerDelegate?.doneVCClick(strDate: dateFormatter.string(from: self.datePicker.date), obj: self.objControl)
        
        print("Done VC..")
    }
    
    @objc func btnCancelClickForVC()
    {
        self.datePicker.removeFromSuperview()
        self.pickerToolbar.removeFromSuperview()
        
        self.datePickerDelegate?.cancelVCClick(obj: self.objControl)
        
        print("Cancel VC..")
    }
    
    @objc func btnDoneClick()
    {
        print("Done..")
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy"
        
        self.datePickerDelegate?.doneClick(strDate: dateFormatter.string(from: self.datePicker.date), textField: self.selectedTextField)
    }
    
    @objc func btnCancelClick()
    {
        print("Cancel..")
        
        self.datePickerDelegate?.cancelClick(textField: self.selectedTextField)
    }
    
    
}
