

import UIKit

protocol RatingViewDelegate {
    
    func submitRatingClick(StrRateValue : String, ratingView:RatingView)
    
}

class RatingView: UIView {

    // MARK: - Delegate
    
    var ratingViewDelegate : RatingViewDelegate!
    
    // MARK: - IBOutlets
    
    @IBOutlet weak var lblTitle : UILabel!
    @IBOutlet weak var btnSubmit : UIButton!
    
    @IBOutlet weak var btnRating1 : UIButton!
    @IBOutlet weak var btnRating2 : UIButton!
    @IBOutlet weak var btnRating3 : UIButton!
    @IBOutlet weak var btnRating4 : UIButton!
    @IBOutlet weak var btnRating5 : UIButton!
    
    var strRateValue : String!
    
    
    // MARK: - Void Methods
    
    func setAllRating() -> Void {
        self.btnRating1.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        self.btnRating2.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        self.btnRating3.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        self.btnRating4.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        self.btnRating5.setImage(UIImage.init(named: "ratingselected"), for: .normal)
    }
    
    func clearAllRating() -> Void {
        self.btnRating1.setImage(UIImage.init(named: "ratingunselected"), for: .normal)
        self.btnRating2.setImage(UIImage.init(named: "ratingunselected"), for: .normal)
        self.btnRating3.setImage(UIImage.init(named: "ratingunselected"), for: .normal)
        self.btnRating4.setImage(UIImage.init(named: "ratingunselected"), for: .normal)
        self.btnRating5.setImage(UIImage.init(named: "ratingunselected"), for: .normal)
    }
    
    // MARK: - IBActions
    
    @IBAction func btnRating1Action(_ sender: UIButton) {
        
        self.clearAllRating()
        self.btnRating1.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        
        self.strRateValue = NSString(format: "\(self.btnRating1.tag)" as NSString) as String!
        print(self.strRateValue)
    }
    
    @IBAction func btnRating2Action(_ sender: UIButton) {
        
        self.clearAllRating()
        self.btnRating1.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        self.btnRating2.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        
        self.strRateValue = NSString(format: "\(self.btnRating2.tag)" as NSString) as String!
        print(self.strRateValue)
    }
    
    @IBAction func btnRating3Action(_ sender: UIButton) {
        
        self.clearAllRating()
        self.btnRating1.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        self.btnRating2.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        self.btnRating3.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        
        self.strRateValue = NSString(format: "\(self.btnRating3.tag)" as NSString) as String!
        print(self.strRateValue)
    }
    
    @IBAction func btnRating4Action(_ sender: UIButton) {
        
        self.clearAllRating()
        self.btnRating1.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        self.btnRating2.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        self.btnRating3.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        self.btnRating4.setImage(UIImage.init(named: "ratingselected"), for: .normal)
        
        self.strRateValue = NSString(format: "\(self.btnRating4.tag)" as NSString) as String!
        print(self.strRateValue)
    }
    
    @IBAction func btnRating5Action(_ sender: UIButton) {
        
        self.clearAllRating()
        self.setAllRating()
        
        self.strRateValue = NSString(format: "\(self.btnRating5.tag)" as NSString) as String!
        print(self.strRateValue)
    }
    
    @IBAction func btnSubmitRatingAction(_ sender: UIButton) {
        if (self.strRateValue != nil) {
            self.ratingViewDelegate.submitRatingClick(StrRateValue: self.strRateValue,ratingView: self)
        }
    }
}
