

import UIKit

protocol ActionSheetDelegate {
    
    //implement this methods for Textfield
    func cancelClick(alertController : UIAlertController, index : Int)
    func otherClick(alertController : UIAlertController, index : Int)
    
}

class ActionSheet: NSObject {
    
    // MARK: - Delegate for AlertMessage
    
    static var actionSheetDelegate : ActionSheetDelegate?
    
    class func showActionSheet(viewController : UIViewController, title : String, message : String, cancelTitle : String, otherTitles: NSMutableArray)
    {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        
        var index = 0
        for  strTitle in otherTitles {
            
            let titleButton = UIAlertAction(title: strTitle as? String, style: .default, handler:{ action in
                print(strTitle)
                self.actionSheetDelegate?.cancelClick(alertController: alertController, index: index)
            })
            
            index = index + 1
            alertController.addAction(titleButton)
        }
        
        if cancelTitle.isEmpty == false
        {
            let cancelButton = UIAlertAction(title: cancelTitle, style: .cancel, handler:{ action in
                print("Cancel")
                self.actionSheetDelegate?.cancelClick(alertController: alertController, index: -1)
            })
            
            alertController.addAction(cancelButton)
        }
        
        viewController.present(alertController, animated: true, completion: nil)
    }
    
}
