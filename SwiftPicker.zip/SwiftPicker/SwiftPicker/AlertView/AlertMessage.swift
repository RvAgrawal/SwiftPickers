

import UIKit


protocol AlertMessageDelegate {
    
    //implement this methods for Textfield
    func cancelClick(alertController : UIAlertController, index : Int)
    func otherClick(alertController : UIAlertController, index : Int)
    
}


class AlertMessage: NSObject {
    
    // MARK: - Delegate for AlertMessage
    
    static var alertMessageDelegate : AlertMessageDelegate?

    class func showAlert(viewController : UIViewController, title : String, message : String, cancelTitle : String, otherTitles: String)
    {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        if cancelTitle.isEmpty == false
        {
            let cancelButton = UIAlertAction(title: cancelTitle, style: .destructive, handler:{ action in
                print("Cancel")
                self.alertMessageDelegate?.cancelClick(alertController: alertController, index: 0)
            })
            
            alertController.addAction(cancelButton)
        }
        
        if otherTitles.isEmpty == false
        {
            let otherButton = UIAlertAction(title: otherTitles, style: .default, handler:{ action in
                print("other")
                self.alertMessageDelegate?.cancelClick(alertController: alertController, index: 1)
            })
            
            alertController.addAction(otherButton)
        }
        
        viewController.present(alertController, animated: true, completion: nil)
    }
    
}
