
import UIKit

protocol GenericPickerDelegate {
    
    //implement this methods for Textfield
    func doneClick(strData:String,textField:UITextField,index:Int)
    func cancelClick(textField:UITextField)

}

class GenericPicker: NSObject,UIPickerViewDelegate,UIPickerViewDataSource {
    
    // MARK: - Delegate for DatePicker
    
    var genericPickerDelegate : GenericPickerDelegate?
    
    // MARK: - Properties For Picker
    var pickerView : UIPickerView!
    var pickerToolbar : UIToolbar!
    
    var selectedTextField : UITextField!
    var arrData : NSMutableArray!
    var isDict : Bool!
    var strKeyValue : String!
    
    // MARK: - Setup DatePicker
    
    func setupDatePicker(textField:UITextField,arrObj:NSMutableArray,key:String,isDict:Bool)
    {
        self.selectedTextField = textField
        self.strKeyValue = key
        
        self.arrData = NSMutableArray(array: arrObj)
        self.isDict = isDict
        
        self.pickerView = UIPickerView()
        self.pickerView.delegate = self
        self.pickerView.backgroundColor = UIColor.white
        
        textField.inputView = self.pickerView
    
        self.setupToolbar(textField: textField)
    }
    
    func setupToolbar(textField:UITextField) {
        
        self.pickerToolbar = UIToolbar(frame: CGRect(x: 0, y: 100, width: self.pickerView.frame.size.width, height: 50))
        //        self.pickerToolbar.barStyle = .default
        
        let btnDone = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.btnDoneClick))
        let btnCancel = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.btnCancelClick))
        
        let fixedSpace:UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        self.pickerToolbar.items = NSArray(objects: btnCancel,fixedSpace,btnDone) as? [UIBarButtonItem]
        
        self.pickerToolbar.sizeToFit()
        self.pickerToolbar.barTintColor = UIColor.darkGray
        self.pickerToolbar.tintColor = UIColor.green
        self.pickerToolbar.isTranslucent = false
        
        //Setting Toolbar as input Accessory View
        textField.inputAccessoryView = self.pickerToolbar
        
    }
    
    
    // MARK: - Toolbar button Click
    
    @objc func btnDoneClick()
    {
        print("Done..")
        let index = self.pickerView.selectedRow(inComponent: 0)
        
        if self.isDict
        {
            let dict = self.arrData.object(at: index) as! NSDictionary
            self.genericPickerDelegate?.doneClick(strData: dict.object(forKey: self.strKeyValue) as! String, textField: self.selectedTextField, index: index)
        }
        else{
            self.genericPickerDelegate?.doneClick(strData: self.arrData.object(at: index) as! String, textField: self.selectedTextField, index: index)
        }
    }
    
    @objc func btnCancelClick()
    {
        print("Cancel..")
        
        self.genericPickerDelegate?.cancelClick(textField: self.selectedTextField)
    }
    
    
    
    // MARK: - Pickerview Delegate
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return self.arrData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        if isDict {
            let dict = self.arrData.object(at: row) as! NSDictionary
            return dict.object(forKey: strKeyValue) as? String
        }
        else{
            return self.arrData.object(at: row) as? String
        }
        
    }
    
}
